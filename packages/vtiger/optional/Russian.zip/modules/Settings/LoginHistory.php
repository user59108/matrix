<?php
/*+**********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 ************************************************************************************/
$languageStrings = array(
    'vtiger_loginhistory' => 'Журнал входа пользователей', 
    'LoginHistory' => 'Журнал входа пользователей', 
    'Login History' => 'Журнал входа пользователей', 
    'LBL_LOGINHISTORY' => 'Журнал входа пользователей', 
    'LBL_LOGIN_HISTORY' => 'Журнал входа пользователей', 
    'SINGLE_loginhistory' => 'Журнал входа пользователей', 
    'User Name' => 'Имя пользователя', 
    'IP Address' => 'IP Адрес', 
    'Signin Time' => 'Время входа', 
    'Signout Time' => 'Время выхода',

);
